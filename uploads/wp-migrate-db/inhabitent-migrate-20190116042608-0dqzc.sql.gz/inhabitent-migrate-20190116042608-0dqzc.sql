# WordPress MySQL database migration
#
# Generated: Wednesday 16. January 2019 04:26 UTC
# Hostname: localhost
# Database: `inhabitent`
# URL: //localhost/inhabitent
# Path: C:\\MAMP\\htdocs\\student
# Tables: wp_cfs_sessions, wp_cfs_values, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, adventure, attachment, cfs, nav_menu_item, oembed_cache, page, post, product, wpcf7_contact_form
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_cfs_sessions`
#

DROP TABLE IF EXISTS `wp_cfs_sessions`;


#
# Table structure of table `wp_cfs_sessions`
#

CREATE TABLE `wp_cfs_sessions` (
  `id` varchar(32) NOT NULL,
  `data` text,
  `expires` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_sessions`
#
INSERT INTO `wp_cfs_sessions` ( `id`, `data`, `expires`) VALUES
('07c278e914e3e11bfb0e63b0e364d850', 'a:7:{s:7:"post_id";i:50;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541319'),
('0af7fd0fb0f1a7689ccd8e55252d914c', 'a:7:{s:7:"post_id";i:59;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541675'),
('18d1a2f80dbe702fc0a7d4da8c732bf1', 'a:7:{s:7:"post_id";i:53;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541457'),
('2b3188e02c1c9ccf484e7e99f7d563d9', 'a:7:{s:7:"post_id";i:58;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541634'),
('2fcc351e626a8f09c1638dfbedd558d1', 'a:7:{s:7:"post_id";i:64;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541983'),
('326cdb3750e0b9bc24313bd09e06cfbb', 'a:7:{s:7:"post_id";i:51;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541359'),
('3508f049a1ae99c2fe7493b7e6200577', 'a:7:{s:7:"post_id";i:54;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541457'),
('4a07e98b25b87bec2242afc211aeaf64', 'a:7:{s:7:"post_id";i:65;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547542020'),
('4e613715dd4d414cc40e58df2dfaccb8', 'a:7:{s:7:"post_id";i:64;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541948'),
('5d67864fd83fccb94ce4c734e1a8cf76', 'a:7:{s:7:"post_id";i:60;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541809'),
('6483910b11cf0f4f6488611427c7ceb7', 'a:7:{s:7:"post_id";i:49;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541217'),
('666e5d3dda7acb7712d6eb2a7343577a', 'a:7:{s:7:"post_id";i:63;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541900'),
('691af0389343bdd1512b43abf33dfe50', 'a:7:{s:7:"post_id";i:52;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541406'),
('6fae5c45c377144854267259e9ddc178', 'a:7:{s:7:"post_id";i:61;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541815'),
('7091968c4c505cc356bdbd5557ed73c0', 'a:7:{s:7:"post_id";i:51;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541320'),
('709a85c2874d2960e22721af4f037189', 'a:7:{s:7:"post_id";i:58;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541584'),
('8384bf84e7b4f46d59bf32adc3d3e310', 'a:7:{s:7:"post_id";i:53;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541409'),
('86ce230edf51cfad113a7b6b15b1f2f3', 'a:7:{s:7:"post_id";i:57;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541535'),
('88beae974e039885a5fa8708548063c4', 'a:7:{s:7:"post_id";i:57;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541572'),
('913580634a59cde357b4368732a24c8f', 'a:7:{s:7:"post_id";i:65;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541984'),
('a0ac9a18bd4e05115bd0c3a8d7de783d', 'a:7:{s:7:"post_id";i:55;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541494'),
('a9ab11e74d8b9aec0999085c9dfc5afa', 'a:7:{s:7:"post_id";i:54;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541493'),
('acebd920d35eb6309ca52bf7626b7f36', 'a:7:{s:7:"post_id";i:50;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541272'),
('af8184e571ff423481116f34ead276f4', 'a:7:{s:7:"post_id";i:52;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541370'),
('bc2e004e24888439bed281de59be4f18', 'a:7:{s:7:"post_id";i:59;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541634'),
('c591aa9d5d09ee61edea46950cdce195', 'a:7:{s:7:"post_id";i:63;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541939'),
('c79682244f2e23a9feb35896df6d3d49', 'a:7:{s:7:"post_id";i:62;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541898'),
('d0a61e762cf17c29171a86335e1722c5', 'a:7:{s:7:"post_id";i:56;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541494'),
('d8402144dec60122c9c13554049acafb', 'a:7:{s:7:"post_id";i:61;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541854'),
('e42be5a62259fb2f7bb665d38a94fc2c', 'a:7:{s:7:"post_id";i:60;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541678'),
('e493fcca97847233ddf5deccbb81def4', 'a:7:{s:7:"post_id";i:49;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541270'),
('fac01f420e07954ac93b2bd97474500f', 'a:7:{s:7:"post_id";i:62;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541867'),
('fe9b913100119643d912609aeda22bea', 'a:7:{s:7:"post_id";i:56;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:47;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1547541534') ;

#
# End of data contents of table `wp_cfs_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_cfs_values`
#

DROP TABLE IF EXISTS `wp_cfs_values`;


#
# Table structure of table `wp_cfs_values`
#

CREATE TABLE `wp_cfs_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `meta_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `base_field_id` int(10) unsigned DEFAULT '0',
  `hierarchy` text,
  `depth` int(10) unsigned DEFAULT '0',
  `weight` int(10) unsigned DEFAULT '0',
  `sub_weight` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id_idx` (`field_id`),
  KEY `post_id_idx` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_values`
#
INSERT INTO `wp_cfs_values` ( `id`, `field_id`, `meta_id`, `post_id`, `base_field_id`, `hierarchy`, `depth`, `weight`, `sub_weight`) VALUES
(1, 1, 99, 49, 0, '', 0, 0, 0),
(2, 1, 103, 50, 0, '', 0, 0, 0),
(3, 1, 107, 51, 0, '', 0, 0, 0),
(4, 1, 111, 52, 0, '', 0, 0, 0),
(5, 1, 115, 53, 0, '', 0, 0, 0),
(6, 1, 119, 54, 0, '', 0, 0, 0),
(7, 1, 124, 56, 0, '', 0, 0, 0),
(8, 1, 128, 57, 0, '', 0, 0, 0),
(9, 1, 132, 58, 0, '', 0, 0, 0),
(10, 1, 136, 59, 0, '', 0, 0, 0),
(11, 1, 140, 60, 0, '', 0, 0, 0),
(12, 1, 144, 61, 0, '', 0, 0, 0),
(13, 1, 148, 62, 0, '', 0, 0, 0),
(14, 1, 152, 63, 0, '', 0, 0, 0),
(15, 1, 156, 64, 0, '', 0, 0, 0),
(16, 1, 160, 65, 0, '', 0, 0, 0) ;

#
# End of data contents of table `wp_cfs_values`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-01-15 03:52:41', '2019-01-15 03:52:41', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/inhabitent', 'yes'),
(2, 'home', 'http://localhost/inhabitent', 'yes'),
(3, 'blogname', 'Inhabitent', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'alexander.hortua10@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:158:{s:10:"product/?$";s:27:"index.php?post_type=product";s:40:"product/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:35:"product/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:27:"product/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:12:"adventure/?$";s:29:"index.php?post_type=adventure";s:42:"adventure/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?post_type=adventure&feed=$matches[1]";s:37:"adventure/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?post_type=adventure&feed=$matches[1]";s:29:"adventure/page/([0-9]{1,})/?$";s:47:"index.php?post_type=adventure&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:37:"adventure/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"adventure/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"adventure/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"adventure/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"adventure/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"adventure/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"adventure/([^/]+)/embed/?$";s:42:"index.php?adventure=$matches[1]&embed=true";s:30:"adventure/([^/]+)/trackback/?$";s:36:"index.php?adventure=$matches[1]&tb=1";s:50:"adventure/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?adventure=$matches[1]&feed=$matches[2]";s:45:"adventure/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?adventure=$matches[1]&feed=$matches[2]";s:38:"adventure/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?adventure=$matches[1]&paged=$matches[2]";s:45:"adventure/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?adventure=$matches[1]&cpage=$matches[2]";s:34:"adventure/([^/]+)(?:/([0-9]+))?/?$";s:48:"index.php?adventure=$matches[1]&page=$matches[2]";s:26:"adventure/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"adventure/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"adventure/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"adventure/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"adventure/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"adventure/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"product-type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product-type=$matches[1]&feed=$matches[2]";s:48:"product-type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product-type=$matches[1]&feed=$matches[2]";s:29:"product-type/([^/]+)/embed/?$";s:45:"index.php?product-type=$matches[1]&embed=true";s:41:"product-type/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?product-type=$matches[1]&paged=$matches[2]";s:23:"product-type/([^/]+)/?$";s:34:"index.php?product-type=$matches[1]";s:31:"cfs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"cfs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"cfs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"cfs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"cfs/([^/]+)/embed/?$";s:51:"index.php?post_type=cfs&name=$matches[1]&embed=true";s:24:"cfs/([^/]+)/trackback/?$";s:45:"index.php?post_type=cfs&name=$matches[1]&tb=1";s:32:"cfs/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&paged=$matches[2]";s:39:"cfs/([^/]+)/comment-page-([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&cpage=$matches[2]";s:28:"cfs/([^/]+)(?:/([0-9]+))?/?$";s:57:"index.php?post_type=cfs&name=$matches[1]&page=$matches[2]";s:20:"cfs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"cfs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"cfs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"cfs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=74&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:12:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:47:"business-hours-widget/business-hours-widget.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:43:"contact-info-widget/contact-info-widget.php";i:4;s:26:"custom-field-suite/cfs.php";i:5;s:23:"debug-bar/debug-bar.php";i:6;s:23:"gutenberg/gutenberg.php";i:7;s:46:"inhabitent-blocks-master/inhabitent-blocks.php";i:8;s:46:"red-functionality-master/red-functionality.php";i:9;s:47:"show-current-template/show-current-template.php";i:10;s:27:"theme-check/theme-check.php";i:11;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'inhabitent', 'yes'),
(41, 'stylesheet', 'inhabitent', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '43764', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '71', 'yes'),
(84, 'page_on_front', '74', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '43764', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:73:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:11:"edit_blocks";b:1;s:18:"edit_others_blocks";b:1;s:14:"publish_blocks";b:1;s:19:"read_private_blocks";b:1;s:11:"read_blocks";b:1;s:13:"delete_blocks";b:1;s:21:"delete_private_blocks";b:1;s:23:"delete_published_blocks";b:1;s:20:"delete_others_blocks";b:1;s:19:"edit_private_blocks";b:1;s:21:"edit_published_blocks";b:1;s:13:"create_blocks";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:46:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:11:"edit_blocks";b:1;s:18:"edit_others_blocks";b:1;s:14:"publish_blocks";b:1;s:19:"read_private_blocks";b:1;s:11:"read_blocks";b:1;s:13:"delete_blocks";b:1;s:21:"delete_private_blocks";b:1;s:23:"delete_published_blocks";b:1;s:20:"delete_others_blocks";b:1;s:19:"edit_private_blocks";b:1;s:21:"edit_published_blocks";b:1;s:13:"create_blocks";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:17:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:11:"edit_blocks";b:1;s:14:"publish_blocks";b:1;s:11:"read_blocks";b:1;s:13:"delete_blocks";b:1;s:23:"delete_published_blocks";b:1;s:21:"edit_published_blocks";b:1;s:13:"create_blocks";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:11:"read_blocks";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'sidebars_widgets', 'a:4:{s:4:"cs-1";a:1:{i:0;s:14:"contact-info-5";}s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:14:"contact-info-2";i:1;s:16:"business-hours-2";i:2;s:10:"archives-2";}s:13:"array_version";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'nonce_key', 'R;IEvGMg-z3a/mQf6q.rRJ!i]3:FiX/^-u3*^5=TCyD({RN{wwL6gK3*wQ0fz,k5', 'no'),
(109, 'nonce_salt', 'lHMb?I@nxI=E^.L!)F_AOXF:2/DCL/i1G,xdsH;kOhVJvHcOW*a&k!<Tq{#QZvf8', 'no'),
(110, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'cron', 'a:5:{i:1547614362;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1547653962;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1547697187;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1547698482;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(114, 'theme_mods_twentynineteen', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1547524811;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(122, 'auth_key', 'Q}!Ih$h)~D!%TZHr6#+L#ck3ee/68`th`JkK,lyV~}hh!wY%a7;CAGibC&1!=~4E', 'no'),
(123, 'auth_salt', 'YsrzS1N=)iH[7G-k*!$v^2jdPf`(K}B#o>|}@4|&o6QK=S7nOyrgd]`$:sbz(R~L', 'no'),
(124, 'logged_in_key', ',?,V]Y<CEq*g+xTb5,IBaYW^cOF7_WV))/Q1@j7aT;n;)&QWb2,!c)EcPDJA60+v', 'no'),
(125, 'logged_in_salt', 'eM[j&11%gsn?jJMfz?M.g*rPNz.^X71UN-E`[N6v=YiAbUowJsIn-*Kj.9y[v2o!', 'no'),
(131, 'can_compress_scripts', '0', 'no'),
(144, 'recently_activated', 'a:1:{s:34:"custom-sidebars/customsidebars.php";i:1547542406;}', 'yes'),
(145, 'widget_business-hours', 'a:2:{i:2;a:4:{s:5:"title";s:14:"Business Hours";s:8:"weekdays";s:10:"9am to 5pm";s:8:"saturday";s:11:"10am to 2pm";s:6:"sunday";s:6:"Closed";}s:12:"_multiwidget";i:1;}', 'yes'),
(146, 'widget_contact-info', 'a:5:{i:2;a:5:{s:5:"title";s:12:"Contact Info";s:9:"telephone";s:12:"778-456-7891";s:5:"email";s:19:"info@inhabitent.com";s:7:"address";s:15:"1490 W Broadway";s:4:"city";s:21:"Vancouver, BC V6H 1H5";}i:3;a:7:{s:5:"title";s:12:"Contact Info";s:9:"telephone";s:0:"";s:5:"email";s:0:"";s:7:"address";s:0:"";s:4:"city";s:0:"";s:14:"csb_visibility";a:3:{s:6:"action";s:4:"show";s:10:"conditions";a:16:{s:5:"guest";a:0:{}s:4:"date";a:0:{}s:5:"roles";a:0:{}s:9:"pagetypes";a:0:{}s:9:"posttypes";a:0:{}s:10:"membership";a:0:{}s:11:"membership2";a:0:{}s:7:"prosite";a:0:{}s:7:"pt-post";a:0:{}s:7:"pt-page";a:0:{}s:10:"pt-product";a:0:{}s:12:"pt-adventure";a:0:{}s:12:"tax-category";a:0:{}s:12:"tax-post_tag";a:0:{}s:15:"tax-post_format";a:0:{}s:16:"tax-product-type";a:0:{}}s:6:"always";b:1;}s:9:"csb_clone";a:2:{s:5:"group";s:1:"1";s:5:"state";s:2:"ok";}}i:4;a:7:{s:5:"title";s:12:"Contact Info";s:9:"telephone";s:0:"";s:5:"email";s:0:"";s:7:"address";s:0:"";s:4:"city";s:0:"";s:14:"csb_visibility";a:3:{s:6:"action";s:4:"show";s:10:"conditions";a:16:{s:5:"guest";a:0:{}s:4:"date";a:0:{}s:5:"roles";a:0:{}s:9:"pagetypes";a:0:{}s:9:"posttypes";a:0:{}s:10:"membership";a:0:{}s:11:"membership2";a:0:{}s:7:"prosite";a:0:{}s:7:"pt-post";a:0:{}s:7:"pt-page";a:0:{}s:10:"pt-product";a:0:{}s:12:"pt-adventure";a:0:{}s:12:"tax-category";a:0:{}s:12:"tax-post_tag";a:0:{}s:15:"tax-post_format";a:0:{}s:16:"tax-product-type";a:0:{}}s:6:"always";b:1;}s:9:"csb_clone";a:2:{s:5:"group";s:1:"1";s:5:"state";s:2:"ok";}}i:5;a:7:{s:5:"title";s:12:"Contact Info";s:9:"telephone";s:0:"";s:5:"email";s:0:"";s:7:"address";s:0:"";s:4:"city";s:0:"";s:14:"csb_visibility";a:3:{s:6:"action";s:4:"show";s:10:"conditions";a:16:{s:5:"guest";a:0:{}s:4:"date";a:0:{}s:5:"roles";a:0:{}s:9:"pagetypes";a:0:{}s:9:"posttypes";a:0:{}s:10:"membership";a:0:{}s:11:"membership2";a:0:{}s:7:"prosite";a:0:{}s:7:"pt-post";a:0:{}s:7:"pt-page";a:0:{}s:10:"pt-product";a:0:{}s:12:"pt-adventure";a:0:{}s:12:"tax-category";a:0:{}s:12:"tax-post_tag";a:0:{}s:15:"tax-post_format";a:0:{}s:16:"tax-product-type";a:0:{}}s:6:"always";b:1;}s:9:"csb_clone";a:2:{s:5:"group";s:1:"2";s:5:"state";s:2:"ok";}}s:12:"_multiwidget";i:1;}', 'yes'),
(147, 'cfs_next_field_id', '2', 'yes'),
(148, 'cfs_version', '2.5.12', 'yes'),
(149, 'current_theme', 'RED Starter Theme', 'yes'),
(150, 'theme_switched', '', 'yes'),
(152, 'theme_mods_inhabitent', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:18;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(168, 'category_children', 'a:0:{}', 'yes'),
(192, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(197, 'product-type_children', 'a:0:{}', 'yes'),
(204, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.1.1";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1547533841;s:7:"version";s:5:"5.1.1";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(237, 'wdev-frash', 'a:3:{s:7:"plugins";a:1:{s:34:"custom-sidebars/customsidebars.php";i:1547542244;}s:5:"queue";a:2:{s:32:"6a9b139509f3226afafc03dc81d90bd2";a:3:{s:6:"plugin";s:34:"custom-sidebars/customsidebars.php";s:4:"type";s:5:"email";s:7:"show_at";i:1547542244;}s:32:"f21a0d5a84b747557fce042d7049df2b";a:3:{s:6:"plugin";s:34:"custom-sidebars/customsidebars.php";s:4:"type";s:4:"rate";s:7:"show_at";i:1548147044;}}s:4:"done";a:0:{}}', 'no'),
(238, 'cs_modifiable', 'a:15:{s:10:"modifiable";a:1:{i:0;s:9:"sidebar-1";}s:7:"authors";a:0:{}s:4:"blog";a:0:{}s:16:"category_archive";a:0:{}s:14:"category_pages";N;s:14:"category_posts";N;s:15:"category_single";a:0:{}s:4:"date";a:0:{}s:8:"defaults";N;s:17:"post_type_archive";a:0:{}s:15:"post_type_pages";N;s:16:"post_type_single";a:0:{}s:6:"search";a:0:{}s:4:"tags";a:0:{}s:6:"screen";N;}', 'yes'),
(239, 'cs_sidebars', 'a:1:{i:0;a:7:{s:2:"id";s:4:"cs-1";s:4:"name";s:10:"footer-bar";s:11:"description";s:0:"";s:13:"before_widget";s:0:"";s:12:"before_title";s:0:"";s:12:"after_widget";s:0:"";s:11:"after_title";s:0:"";}}', 'yes'),
(269, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1547612768;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_wp_trash_meta_status', 'publish'),
(4, 1, '_wp_trash_meta_time', '1547525514'),
(5, 1, '_wp_desired_post_slug', 'hello-world'),
(6, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(7, 6, '_wp_attached_file', '2019/01/beach-bonfire-1.jpg'),
(8, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:27:"2019/01/beach-bonfire-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"beach-bonfire-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"beach-bonfire-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"beach-bonfire-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"beach-bonfire-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(9, 7, '_wp_attached_file', '2019/01/canoe-girl-1.jpg'),
(10, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:24:"2019/01/canoe-girl-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"canoe-girl-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"canoe-girl-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"canoe-girl-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"canoe-girl-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(11, 8, '_wp_attached_file', '2019/01/mountain-hikers-1.jpg'),
(12, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:29:"2019/01/mountain-hikers-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"mountain-hikers-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"mountain-hikers-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"mountain-hikers-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"mountain-hikers-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(13, 9, '_wp_attached_file', '2019/01/night-sky-1.jpg'),
(14, 9, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:23:"2019/01/night-sky-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"night-sky-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"night-sky-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"night-sky-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"night-sky-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(15, 10, '_wp_attached_file', '2019/01/glamping-2.jpg'),
(16, 10, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:22:"2019/01/glamping-2.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"glamping-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"glamping-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"glamping-2-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"glamping-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(17, 11, '_wp_attached_file', '2019/01/healthy-camp-food-1.jpg'),
(18, 11, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:31:"2019/01/healthy-camp-food-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"healthy-camp-food-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"healthy-camp-food-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"healthy-camp-food-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"healthy-camp-food-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(19, 12, '_wp_attached_file', '2019/01/solo-camping-1.jpg'),
(20, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2515;s:6:"height";i:1830;s:4:"file";s:26:"2019/01/solo-camping-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"solo-camping-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"solo-camping-1-300x218.jpg";s:5:"width";i:300;s:6:"height";i:218;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"solo-camping-1-768x559.jpg";s:5:"width";i:768;s:6:"height";i:559;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"solo-camping-1-1024x745.jpg";s:5:"width";i:1024;s:6:"height";i:745;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(21, 13, '_wp_attached_file', '2019/01/van-camper-1.jpg'),
(22, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1026;s:4:"file";s:24:"2019/01/van-camper-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"van-camper-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"van-camper-1-300x205.jpg";s:5:"width";i:300;s:6:"height";i:205;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"van-camper-1-768x525.jpg";s:5:"width";i:768;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"van-camper-1-1024x700.jpg";s:5:"width";i:1024;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(23, 14, '_wp_attached_file', '2019/01/warm-cocktail-1.jpg'),
(24, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:27:"2019/01/warm-cocktail-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"warm-cocktail-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"warm-cocktail-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"warm-cocktail-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"warm-cocktail-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(25, 15, '_wp_attached_file', '2019/01/beach-tent-1.jpg'),
(26, 15, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:24:"2019/01/beach-tent-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"beach-tent-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"beach-tent-1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"beach-tent-1-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"beach-tent-1-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(27, 16, '_wp_attached_file', '2019/01/camper-van-1.jpg'),
(28, 16, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:24:"2019/01/camper-van-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"camper-van-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"camper-van-1-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"camper-van-1-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"camper-van-1-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(29, 17, '_wp_attached_file', '2019/01/ceramic-mugs-1.jpg'),
(30, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:26:"2019/01/ceramic-mugs-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"ceramic-mugs-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"ceramic-mugs-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"ceramic-mugs-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"ceramic-mugs-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(31, 18, '_wp_attached_file', '2019/01/film-cameras-1.jpg'),
(32, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:26:"2019/01/film-cameras-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"film-cameras-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"film-cameras-1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"film-cameras-1-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"film-cameras-1-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(33, 19, '_wp_attached_file', '2019/01/flannel-shirt-1.jpg'),
(34, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:27:"2019/01/flannel-shirt-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"flannel-shirt-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"flannel-shirt-1-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"flannel-shirt-1-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"flannel-shirt-1-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(35, 20, '_wp_attached_file', '2019/01/gas-stove-1.jpg'),
(36, 20, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:23:"2019/01/gas-stove-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"gas-stove-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"gas-stove-1-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"gas-stove-1-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"gas-stove-1-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(37, 21, '_wp_attached_file', '2019/01/hand-knit-toque-1.jpg'),
(38, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1845;s:4:"file";s:29:"2019/01/hand-knit-toque-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"hand-knit-toque-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"hand-knit-toque-1-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"hand-knit-toque-1-768x545.jpg";s:5:"width";i:768;s:6:"height";i:545;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"hand-knit-toque-1-1024x727.jpg";s:5:"width";i:1024;s:6:"height";i:727;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(39, 22, '_wp_attached_file', '2019/01/hiking-boots-1.jpg'),
(40, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2376;s:6:"height";i:1782;s:4:"file";s:26:"2019/01/hiking-boots-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"hiking-boots-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"hiking-boots-1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"hiking-boots-1-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"hiking-boots-1-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(41, 23, '_wp_attached_file', '2019/01/large-thermos-1.jpg'),
(42, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:27:"2019/01/large-thermos-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"large-thermos-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"large-thermos-1-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"large-thermos-1-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"large-thermos-1-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(43, 24, '_wp_attached_file', '2019/01/leather-satchel-1.jpg'),
(44, 24, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:29:"2019/01/leather-satchel-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"leather-satchel-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"leather-satchel-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"leather-satchel-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"leather-satchel-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(45, 25, '_wp_attached_file', '2019/01/nylon-tents-1.jpg'),
(46, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1732;s:4:"file";s:25:"2019/01/nylon-tents-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"nylon-tents-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"nylon-tents-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"nylon-tents-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"nylon-tents-1-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(47, 26, '_wp_attached_file', '2019/01/rustic-tools-1.jpg'),
(48, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:2111;s:4:"file";s:26:"2019/01/rustic-tools-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"rustic-tools-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"rustic-tools-1-300x244.jpg";s:5:"width";i:300;s:6:"height";i:244;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"rustic-tools-1-768x624.jpg";s:5:"width";i:768;s:6:"height";i:624;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"rustic-tools-1-1024x831.jpg";s:5:"width";i:1024;s:6:"height";i:831;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(49, 27, '_wp_attached_file', '2019/01/stew-can-1.jpg'),
(50, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:22:"2019/01/stew-can-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"stew-can-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"stew-can-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"stew-can-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"stew-can-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(51, 28, '_wp_attached_file', '2019/01/travel-hammock-1.jpg'),
(52, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2288;s:6:"height";i:1520;s:4:"file";s:28:"2019/01/travel-hammock-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"travel-hammock-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"travel-hammock-1-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"travel-hammock-1-768x510.jpg";s:5:"width";i:768;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"travel-hammock-1-1024x680.jpg";s:5:"width";i:1024;s:6:"height";i:680;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(53, 29, '_wp_attached_file', '2019/01/weathered-canoes-1.jpg'),
(54, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:30:"2019/01/weathered-canoes-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"weathered-canoes-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"weathered-canoes-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"weathered-canoes-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:31:"weathered-canoes-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(55, 30, '_wp_attached_file', '2019/01/wood-ax-1.jpg'),
(56, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:21:"2019/01/wood-ax-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"wood-ax-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"wood-ax-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"wood-ax-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"wood-ax-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(57, 31, '_edit_lock', '1547525887:1'),
(60, 31, '_thumbnail_id', '13'),
(61, 33, '_edit_lock', '1547525761:1'),
(64, 31, '_wp_old_date', '2019-01-15'),
(65, 34, '_edit_lock', '1547525882:1'),
(68, 34, '_wp_old_date', '2019-01-15'),
(69, 34, '_thumbnail_id', '14'),
(70, 36, '_edit_lock', '1547525970:1'),
(73, 36, '_wp_old_date', '2019-01-15'),
(74, 36, '_thumbnail_id', '11'),
(75, 38, '_edit_lock', '1547526045:1'),
(78, 38, '_wp_old_date', '2019-01-15'),
(79, 38, '_thumbnail_id', '12'),
(80, 40, '_edit_lock', '1547526315:1'),
(83, 40, '_wp_old_date', '2019-01-15'),
(84, 40, '_thumbnail_id', '10'),
(85, 42, '_edit_lock', '1547547459:1'),
(86, 42, '_thumbnail_id', '7'),
(87, 43, '_edit_lock', '1547546530:1'),
(88, 44, '_edit_lock', '1547546524:1'),
(89, 45, '_edit_lock', '1547546518:1'),
(90, 46, '_edit_lock', '1547526551:1'),
(91, 47, '_edit_last', '1'),
(92, 47, 'cfs_fields', 'a:1:{i:0;a:8:{s:2:"id";s:1:"1";s:4:"name";s:5:"price";s:5:"label";s:5:"PRICE";s:4:"type";s:4:"text";s:5:"notes";s:0:"";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:13:"default_value";s:1:"$";s:8:"required";s:1:"0";}}}'),
(93, 47, 'cfs_rules', 'a:1:{s:10:"post_types";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:7:"product";}}}'),
(94, 47, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(95, 47, '_edit_lock', '1547526668:1'),
(96, 48, '_edit_lock', '1547526612:1'),
(97, 49, '_edit_lock', '1547526870:1'),
(98, 49, '_thumbnail_id', '18'),
(99, 49, 'price', '$150.00'),
(100, 49, '_edit_last', '1'),
(101, 50, '_edit_lock', '1547526919:1'),
(102, 50, '_thumbnail_id', '26'),
(103, 50, 'price', '$100.00'),
(104, 50, '_edit_last', '1'),
(105, 51, '_edit_lock', '1547526959:1'),
(106, 51, '_thumbnail_id', '29'),
(107, 51, 'price', '$400.00'),
(108, 51, '_edit_last', '1'),
(109, 52, '_edit_lock', '1547527006:1'),
(110, 52, '_thumbnail_id', '30'),
(111, 52, 'price', '$40.00'),
(112, 52, '_edit_last', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(113, 53, '_edit_lock', '1547527057:1'),
(114, 53, '_thumbnail_id', '17'),
(115, 53, 'price', '$19.00'),
(116, 53, '_edit_last', '1'),
(117, 54, '_edit_lock', '1547527093:1'),
(118, 54, '_thumbnail_id', '20'),
(119, 54, 'price', '$120.00'),
(120, 54, '_edit_last', '1'),
(121, 55, '_edit_lock', '1547527094:1'),
(122, 56, '_edit_lock', '1547527134:1'),
(123, 56, '_thumbnail_id', '23'),
(124, 56, 'price', '$42.00'),
(125, 56, '_edit_last', '1'),
(126, 57, '_edit_lock', '1547527172:1'),
(127, 57, '_thumbnail_id', '27'),
(128, 57, 'price', '$22.00'),
(129, 57, '_edit_last', '1'),
(130, 58, '_edit_lock', '1547527234:1'),
(131, 58, '_thumbnail_id', '15'),
(132, 58, 'price', '$155.00'),
(133, 58, '_edit_last', '1'),
(134, 59, '_edit_lock', '1547527275:1'),
(135, 59, '_thumbnail_id', '16'),
(136, 59, 'price', '$2500.00'),
(137, 59, '_edit_last', '1'),
(138, 60, '_edit_lock', '1547527409:1'),
(139, 60, '_thumbnail_id', '25'),
(140, 60, 'price', '$220.00'),
(141, 60, '_edit_last', '1'),
(142, 61, '_edit_lock', '1547527454:1'),
(143, 61, '_thumbnail_id', '28'),
(144, 61, 'price', '$75.00'),
(145, 61, '_edit_last', '1'),
(146, 62, '_edit_lock', '1547527498:1'),
(147, 62, '_thumbnail_id', '19'),
(148, 62, 'price', '$45.00'),
(149, 62, '_edit_last', '1'),
(150, 63, '_edit_lock', '1547527539:1'),
(151, 63, '_thumbnail_id', '21'),
(152, 63, 'price', '$28.00'),
(153, 63, '_edit_last', '1'),
(154, 64, '_edit_lock', '1547527582:1'),
(155, 64, '_thumbnail_id', '22'),
(156, 64, 'price', '$135.00'),
(157, 64, '_edit_last', '1'),
(158, 65, '_edit_lock', '1547527559:1'),
(159, 65, '_thumbnail_id', '24'),
(160, 65, 'price', '$60.00'),
(161, 65, '_edit_last', '1'),
(162, 66, '_edit_lock', '1547547042:1'),
(163, 68, '_edit_lock', '1547527783:1'),
(164, 69, '_edit_lock', '1547538555:1'),
(165, 71, '_edit_lock', '1547527708:1'),
(166, 74, '_edit_lock', '1547527744:1'),
(167, 76, '_menu_item_type', 'post_type'),
(168, 76, '_menu_item_menu_item_parent', '0'),
(169, 76, '_menu_item_object_id', '74'),
(170, 76, '_menu_item_object', 'page'),
(171, 76, '_menu_item_target', ''),
(172, 76, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(173, 76, '_menu_item_xfn', ''),
(174, 76, '_menu_item_url', ''),
(175, 76, '_menu_item_orphaned', '1547527952'),
(176, 77, '_menu_item_type', 'post_type'),
(177, 77, '_menu_item_menu_item_parent', '0'),
(178, 77, '_menu_item_object_id', '66'),
(179, 77, '_menu_item_object', 'page'),
(180, 77, '_menu_item_target', ''),
(181, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(182, 77, '_menu_item_xfn', ''),
(183, 77, '_menu_item_url', ''),
(184, 77, '_menu_item_orphaned', '1547527952'),
(185, 78, '_menu_item_type', 'post_type'),
(186, 78, '_menu_item_menu_item_parent', '0'),
(187, 78, '_menu_item_object_id', '69'),
(188, 78, '_menu_item_object', 'page'),
(189, 78, '_menu_item_target', ''),
(190, 78, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(191, 78, '_menu_item_xfn', ''),
(192, 78, '_menu_item_url', ''),
(193, 78, '_menu_item_orphaned', '1547527952'),
(194, 79, '_menu_item_type', 'post_type'),
(195, 79, '_menu_item_menu_item_parent', '0'),
(196, 79, '_menu_item_object_id', '74'),
(197, 79, '_menu_item_object', 'page'),
(198, 79, '_menu_item_target', ''),
(199, 79, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(200, 79, '_menu_item_xfn', ''),
(201, 79, '_menu_item_url', ''),
(202, 79, '_menu_item_orphaned', '1547527953'),
(203, 80, '_menu_item_type', 'post_type'),
(204, 80, '_menu_item_menu_item_parent', '0'),
(205, 80, '_menu_item_object_id', '71'),
(206, 80, '_menu_item_object', 'page'),
(207, 80, '_menu_item_target', ''),
(208, 80, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(209, 80, '_menu_item_xfn', ''),
(210, 80, '_menu_item_url', ''),
(211, 80, '_menu_item_orphaned', '1547527953'),
(212, 81, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(213, 81, '_menu_item_menu_item_parent', '0'),
(214, 81, '_menu_item_object_id', '2'),
(215, 81, '_menu_item_object', 'page'),
(216, 81, '_menu_item_target', ''),
(217, 81, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(218, 81, '_menu_item_xfn', ''),
(219, 81, '_menu_item_url', ''),
(220, 81, '_menu_item_orphaned', '1547527953'),
(221, 82, '_menu_item_type', 'post_type'),
(222, 82, '_menu_item_menu_item_parent', '0'),
(223, 82, '_menu_item_object_id', '74'),
(224, 82, '_menu_item_object', 'page'),
(225, 82, '_menu_item_target', ''),
(226, 82, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(227, 82, '_menu_item_xfn', ''),
(228, 82, '_menu_item_url', ''),
(229, 82, '_menu_item_orphaned', '1547531449'),
(230, 83, '_menu_item_type', 'post_type'),
(231, 83, '_menu_item_menu_item_parent', '0'),
(232, 83, '_menu_item_object_id', '66'),
(233, 83, '_menu_item_object', 'page'),
(234, 83, '_menu_item_target', ''),
(235, 83, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(236, 83, '_menu_item_xfn', ''),
(237, 83, '_menu_item_url', ''),
(239, 84, '_menu_item_type', 'post_type'),
(240, 84, '_menu_item_menu_item_parent', '0'),
(241, 84, '_menu_item_object_id', '69'),
(242, 84, '_menu_item_object', 'page'),
(243, 84, '_menu_item_target', ''),
(244, 84, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(245, 84, '_menu_item_xfn', ''),
(246, 84, '_menu_item_url', ''),
(248, 85, '_menu_item_type', 'post_type'),
(249, 85, '_menu_item_menu_item_parent', '0'),
(250, 85, '_menu_item_object_id', '74'),
(251, 85, '_menu_item_object', 'page'),
(252, 85, '_menu_item_target', ''),
(253, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(254, 85, '_menu_item_xfn', ''),
(255, 85, '_menu_item_url', ''),
(256, 85, '_menu_item_orphaned', '1547531449'),
(257, 86, '_menu_item_type', 'post_type'),
(258, 86, '_menu_item_menu_item_parent', '0'),
(259, 86, '_menu_item_object_id', '71'),
(260, 86, '_menu_item_object', 'page'),
(261, 86, '_menu_item_target', ''),
(262, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(263, 86, '_menu_item_xfn', ''),
(264, 86, '_menu_item_url', ''),
(266, 87, '_menu_item_type', 'post_type'),
(267, 87, '_menu_item_menu_item_parent', '0'),
(268, 87, '_menu_item_object_id', '2'),
(269, 87, '_menu_item_object', 'page'),
(270, 87, '_menu_item_target', ''),
(271, 87, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(272, 87, '_menu_item_xfn', ''),
(273, 87, '_menu_item_url', ''),
(274, 87, '_menu_item_orphaned', '1547531449'),
(275, 88, '_menu_item_type', 'custom'),
(276, 88, '_menu_item_menu_item_parent', '0'),
(277, 88, '_menu_item_object_id', '88'),
(278, 88, '_menu_item_object', 'custom'),
(279, 88, '_menu_item_target', ''),
(280, 88, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(281, 88, '_menu_item_xfn', ''),
(282, 88, '_menu_item_url', 'http://localhost/inhabitent/product/'),
(284, 91, '_form', '<h2>SEND US EMAIL!</h2>\n<p>Want to join the discussion? Feel free to contribute!</p>\n\n<label> COMMENT\n    [textarea your-message] </label>\n\n<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> WEBSITE\n    [text your-subject] </label>\n\n\n\n[submit "SUBMIT"]'),
(285, 91, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:27:"Inhabitent "[your-subject]"";s:6:"sender";s:41:"Inhabitent <alexander.hortua10@gmail.com>";s:9:"recipient";s:28:"alexander.hortua10@gmail.com";s:4:"body";s:173:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(286, 91, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:27:"Inhabitent "[your-subject]"";s:6:"sender";s:41:"Inhabitent <alexander.hortua10@gmail.com>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:115:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)";s:18:"additional_headers";s:38:"Reply-To: alexander.hortua10@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(287, 91, '_messages', 'a:23:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";s:12:"invalid_date";s:29:"The date format is incorrect.";s:14:"date_too_early";s:44:"The date is before the earliest one allowed.";s:13:"date_too_late";s:41:"The date is after the latest one allowed.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:20:"The file is too big.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:14:"invalid_number";s:29:"The number format is invalid.";s:16:"number_too_small";s:47:"The number is smaller than the minimum allowed.";s:16:"number_too_large";s:46:"The number is larger than the maximum allowed.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:13:"invalid_email";s:38:"The e-mail address entered is invalid.";s:11:"invalid_url";s:19:"The URL is invalid.";s:11:"invalid_tel";s:32:"The telephone number is invalid.";}'),
(288, 91, '_additional_settings', ''),
(289, 91, '_locale', 'en_US'),
(290, 99, '_form', '<h2>SEND US EMAIL!</h2>\n\n<label> NAME <span class="asteristc">*</span>\n    [text* your-name] </label>\n\n<label> EMAIL <span class="asteristc">*</span> \n    [email* your-email] </label>\n\n<label> SUBJECT <span class="asteristc">*</span>\n    [text* your-subject] </label>\n\n<label> MESSAGE <span class="asteristc">*</span>\n    [textarea* your-message] </label>\n\n\n[submit "SUBMIT"]'),
(291, 99, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:27:"Inhabitent "[your-subject]"";s:6:"sender";s:41:"Inhabitent <alexander.hortua10@gmail.com>";s:9:"recipient";s:28:"alexander.hortua10@gmail.com";s:4:"body";s:173:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(292, 99, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:27:"Inhabitent "[your-subject]"";s:6:"sender";s:41:"Inhabitent <alexander.hortua10@gmail.com>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:115:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)";s:18:"additional_headers";s:38:"Reply-To: alexander.hortua10@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(293, 99, '_messages', 'a:23:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";s:12:"invalid_date";s:29:"The date format is incorrect.";s:14:"date_too_early";s:44:"The date is before the earliest one allowed.";s:13:"date_too_late";s:41:"The date is after the latest one allowed.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:20:"The file is too big.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:14:"invalid_number";s:29:"The number format is invalid.";s:16:"number_too_small";s:47:"The number is smaller than the minimum allowed.";s:16:"number_too_large";s:46:"The number is larger than the maximum allowed.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:13:"invalid_email";s:38:"The e-mail address entered is invalid.";s:11:"invalid_url";s:19:"The URL is invalid.";s:11:"invalid_tel";s:32:"The telephone number is invalid.";}'),
(294, 99, '_additional_settings', ''),
(295, 99, '_locale', 'en_US') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-01-15 03:52:41', '2019-01-15 03:52:41', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2019-01-15 04:11:54', '2019-01-15 04:11:54', '', 0, 'http://localhost/inhabitent/?p=1', 0, 'post', '', 1),
(2, 1, '2019-01-15 03:52:41', '2019-01-15 03:52:41', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/inhabitent/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2019-01-15 03:52:41', '2019-01-15 03:52:41', '', 0, 'http://localhost/inhabitent/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-01-15 03:52:41', '2019-01-15 03:52:41', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost/inhabitent.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2019-01-15 03:52:41', '2019-01-15 03:52:41', '', 0, 'http://localhost/inhabitent/?page_id=3', 0, 'page', '', 0),
(4, 1, '2019-01-15 03:53:07', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-01-15 03:53:07', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=4', 0, 'post', '', 0),
(5, 1, '2019-01-15 04:11:54', '2019-01-15 04:11:54', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-01-15 04:11:54', '2019-01-15 04:11:54', '', 1, 'http://localhost/inhabitent/2019/01/15/1-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2019-01-15 04:13:14', '2019-01-15 04:13:14', '', 'beach-bonfire', '', 'inherit', 'open', 'closed', '', 'beach-bonfire', '', '', '2019-01-15 04:13:14', '2019-01-15 04:13:14', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/beach-bonfire-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(7, 1, '2019-01-15 04:13:18', '2019-01-15 04:13:18', '', 'canoe-girl', '', 'inherit', 'open', 'closed', '', 'canoe-girl', '', '', '2019-01-15 04:13:18', '2019-01-15 04:13:18', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/canoe-girl-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2019-01-15 04:13:19', '2019-01-15 04:13:19', '', 'mountain-hikers', '', 'inherit', 'open', 'closed', '', 'mountain-hikers', '', '', '2019-01-15 04:13:19', '2019-01-15 04:13:19', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/mountain-hikers-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2019-01-15 04:13:20', '2019-01-15 04:13:20', '', 'night-sky', '', 'inherit', 'open', 'closed', '', 'night-sky', '', '', '2019-01-15 04:13:20', '2019-01-15 04:13:20', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/night-sky-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(10, 1, '2019-01-15 04:14:05', '2019-01-15 04:14:05', '', 'glamping', '', 'inherit', 'open', 'closed', '', 'glamping', '', '', '2019-01-15 04:14:05', '2019-01-15 04:14:05', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/glamping-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(11, 1, '2019-01-15 04:14:06', '2019-01-15 04:14:06', '', 'healthy-camp-food', '', 'inherit', 'open', 'closed', '', 'healthy-camp-food', '', '', '2019-01-15 04:14:06', '2019-01-15 04:14:06', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/healthy-camp-food-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(12, 1, '2019-01-15 04:14:07', '2019-01-15 04:14:07', '', 'solo-camping', '', 'inherit', 'open', 'closed', '', 'solo-camping', '', '', '2019-01-15 04:14:07', '2019-01-15 04:14:07', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/solo-camping-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 1, '2019-01-15 04:14:09', '2019-01-15 04:14:09', '', 'van-camper', '', 'inherit', 'open', 'closed', '', 'van-camper', '', '', '2019-01-15 04:14:09', '2019-01-15 04:14:09', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/van-camper-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2019-01-15 04:14:10', '2019-01-15 04:14:10', '', 'warm-cocktail', '', 'inherit', 'open', 'closed', '', 'warm-cocktail', '', '', '2019-01-15 04:14:10', '2019-01-15 04:14:10', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/warm-cocktail-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(15, 1, '2019-01-15 04:14:13', '2019-01-15 04:14:13', '', 'beach-tent', '', 'inherit', 'open', 'closed', '', 'beach-tent', '', '', '2019-01-15 04:14:13', '2019-01-15 04:14:13', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/beach-tent-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2019-01-15 04:14:14', '2019-01-15 04:14:14', '', 'camper-van', '', 'inherit', 'open', 'closed', '', 'camper-van', '', '', '2019-01-15 04:14:14', '2019-01-15 04:14:14', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/camper-van-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2019-01-15 04:14:15', '2019-01-15 04:14:15', '', 'ceramic-mugs', '', 'inherit', 'open', 'closed', '', 'ceramic-mugs', '', '', '2019-01-15 04:14:15', '2019-01-15 04:14:15', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/ceramic-mugs-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2019-01-15 04:14:16', '2019-01-15 04:14:16', '', 'film-cameras', '', 'inherit', 'open', 'closed', '', 'film-cameras', '', '', '2019-01-15 04:14:16', '2019-01-15 04:14:16', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/film-cameras-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2019-01-15 04:14:17', '2019-01-15 04:14:17', '', 'flannel-shirt', '', 'inherit', 'open', 'closed', '', 'flannel-shirt', '', '', '2019-01-15 04:14:17', '2019-01-15 04:14:17', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/flannel-shirt-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2019-01-15 04:14:18', '2019-01-15 04:14:18', '', 'gas-stove', '', 'inherit', 'open', 'closed', '', 'gas-stove', '', '', '2019-01-15 04:14:18', '2019-01-15 04:14:18', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/gas-stove-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 1, '2019-01-15 04:14:19', '2019-01-15 04:14:19', '', 'hand-knit-toque', '', 'inherit', 'open', 'closed', '', 'hand-knit-toque', '', '', '2019-01-15 04:14:19', '2019-01-15 04:14:19', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/hand-knit-toque-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2019-01-15 04:14:20', '2019-01-15 04:14:20', '', 'hiking-boots', '', 'inherit', 'open', 'closed', '', 'hiking-boots', '', '', '2019-01-15 04:14:20', '2019-01-15 04:14:20', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/hiking-boots-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2019-01-15 04:14:21', '2019-01-15 04:14:21', '', 'large-thermos', '', 'inherit', 'open', 'closed', '', 'large-thermos', '', '', '2019-01-15 04:14:21', '2019-01-15 04:14:21', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/large-thermos-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2019-01-15 04:14:22', '2019-01-15 04:14:22', '', 'leather-satchel', '', 'inherit', 'open', 'closed', '', 'leather-satchel', '', '', '2019-01-15 04:14:22', '2019-01-15 04:14:22', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/leather-satchel-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(25, 1, '2019-01-15 04:14:23', '2019-01-15 04:14:23', '', 'nylon-tents', '', 'inherit', 'open', 'closed', '', 'nylon-tents', '', '', '2019-01-15 04:14:23', '2019-01-15 04:14:23', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/nylon-tents-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2019-01-15 04:14:25', '2019-01-15 04:14:25', '', 'rustic-tools', '', 'inherit', 'open', 'closed', '', 'rustic-tools', '', '', '2019-01-15 04:14:25', '2019-01-15 04:14:25', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/rustic-tools-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2019-01-15 04:14:27', '2019-01-15 04:14:27', '', 'stew-can', '', 'inherit', 'open', 'closed', '', 'stew-can', '', '', '2019-01-15 04:14:27', '2019-01-15 04:14:27', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/stew-can-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2019-01-15 04:14:29', '2019-01-15 04:14:29', '', 'travel-hammock', '', 'inherit', 'open', 'closed', '', 'travel-hammock', '', '', '2019-01-15 04:14:29', '2019-01-15 04:14:29', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/travel-hammock-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2019-01-15 04:14:31', '2019-01-15 04:14:31', '', 'weathered-canoes', '', 'inherit', 'open', 'closed', '', 'weathered-canoes', '', '', '2019-01-15 04:14:31', '2019-01-15 04:14:31', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/weathered-canoes-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2019-01-15 04:14:32', '2019-01-15 04:14:32', '', 'wood-ax', '', 'inherit', 'open', 'closed', '', 'wood-ax', '', '', '2019-01-15 04:14:32', '2019-01-15 04:14:32', '', 0, 'http://localhost/inhabitent/wp-content/uploads/2019/01/wood-ax-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2018-04-14 04:18:12', '2018-04-14 04:18:12', '<!-- wp:paragraph -->\n<p>Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.<br></p>\n<!-- /wp:paragraph -->', 'VAN CAMPING PHOTO CONTEST', '', 'publish', 'open', 'open', '', 'van-camping-photo-contest', '', '', '2019-01-15 04:18:49', '2019-01-15 04:18:49', '', 0, 'http://localhost/inhabitent/?p=31', 0, 'post', '', 0),
(32, 1, '2019-01-15 04:18:12', '2019-01-15 04:18:12', '<!-- wp:paragraph -->\n<p>Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.<br></p>\n<!-- /wp:paragraph -->', 'VAN CAMPING PHOTO CONTEST', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2019-01-15 04:18:12', '2019-01-15 04:18:12', '', 31, 'http://localhost/inhabitent/2019/01/15/31-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2019-01-15 04:18:20', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-01-15 04:18:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=33', 0, 'post', '', 0),
(34, 1, '2018-04-02 04:19:06', '2018-04-02 04:19:06', '<!-- wp:paragraph -->\n<p>Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</p>\n<!-- /wp:paragraph -->', 'FIRESIDE LIBATIONS: 3 WARM COCKTAIL RECIPES', '', 'publish', 'open', 'open', '', 'fireside-libations-3-warm-cocktail-recipes', '', '', '2019-01-15 04:20:17', '2019-01-15 04:20:17', '', 0, 'http://localhost/inhabitent/?p=34', 0, 'post', '', 0),
(35, 1, '2019-01-15 04:20:17', '2019-01-15 04:20:17', '<!-- wp:paragraph -->\n<p>Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</p>\n<!-- /wp:paragraph -->', 'FIRESIDE LIBATIONS: 3 WARM COCKTAIL RECIPES', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2019-01-15 04:20:17', '2019-01-15 04:20:17', '', 34, 'http://localhost/inhabitent/2019/01/15/34-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2018-03-31 04:20:37', '2018-03-31 04:20:37', '<!-- wp:paragraph -->\n<p>Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'HOW TO: EATING HEALTHY MEALS IN THE WILD', '', 'publish', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild', '', '', '2019-01-15 04:21:50', '2019-01-15 04:21:50', '', 0, 'http://localhost/inhabitent/?p=36', 0, 'post', '', 0),
(37, 1, '2019-01-15 04:21:50', '2019-01-15 04:21:50', '<!-- wp:paragraph -->\n<p>Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</p>\n<!-- /wp:paragraph -->', 'HOW TO: EATING HEALTHY MEALS IN THE WILD', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2019-01-15 04:21:50', '2019-01-15 04:21:50', '', 36, 'http://localhost/inhabitent/2019/01/15/36-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2018-03-19 04:21:55', '2018-03-19 04:21:55', '<!-- wp:paragraph -->\n<p>Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Venmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.</p>\n<!-- /wp:paragraph -->', '5 TIPS FOR SOLO CAMPING', '', 'publish', 'open', 'open', '', '5-tips-for-solo-camping', '', '', '2019-01-15 04:23:06', '2019-01-15 04:23:06', '', 0, 'http://localhost/inhabitent/?p=38', 0, 'post', '', 0),
(39, 1, '2019-01-15 04:23:06', '2019-01-15 04:23:06', '<!-- wp:paragraph -->\n<p>Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Venmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.</p>\n<!-- /wp:paragraph -->', '5 TIPS FOR SOLO CAMPING', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2019-01-15 04:23:06', '2019-01-15 04:23:06', '', 38, 'http://localhost/inhabitent/2019/01/15/38-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2018-03-10 04:23:13', '2018-03-10 04:23:13', '<!-- wp:paragraph -->\n<p>Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Viral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.</p>\n<!-- /wp:paragraph -->', 'GLAMPING MADE EASY', '', 'publish', 'open', 'open', '', 'glamping-made-easy', '', '', '2019-01-15 04:24:34', '2019-01-15 04:24:34', '', 0, 'http://localhost/inhabitent/?p=40', 0, 'post', '', 0),
(41, 1, '2019-01-15 04:24:34', '2019-01-15 04:24:34', '<!-- wp:paragraph -->\n<p>Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Viral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.</p>\n<!-- /wp:paragraph -->', 'GLAMPING MADE EASY', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-15 04:24:34', '2019-01-15 04:24:34', '', 40, 'http://localhost/inhabitent/2019/01/15/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2019-01-15 04:28:30', '2019-01-15 04:28:30', '<!-- wp:paragraph {"placeholder":"Add Description"} -->\n<p>Semiotics flannel artisan, squid whatever YOLO cold-pressed thundercats slow-carb normcore. Meggings lo-fi franzen waistcoat tattooed, pour-over etsy artisan. Seitan butcher tacos gentrify. Raw denim fap yr shabby chic. Thundercats mustache mlkshk messenger bag. Cronut crucifix wolf, artisan VHS skateboard chambray single-origin coffee fap. Shabby chic brooklyn meh kale chips, pour-over forage farm-to-table irony flannel mumblecore heirloom pickled cred.\n\nSwag chillwave chicharrones quinoa. Plaid yr small batch four loko. Polaroid scenester tattooed, biodiesel quinoa mumblecore 3 wolf moon leggings iPhone small batch sartorial meditation pop-up cardigan. Chillwave kitsch asymmetrical artisan, actually kogi cronut portland pork belly cardigan sustainable. Letterpress hammock heirloom kogi selvage biodiesel. Scenester occupy cornhole, banh mi post-ironic taxidermy crucifix mumblecore. Authentic pug next level, health goth slow-carb truffaut neutra literally biodiesel butcher retro.\n\nIntelligentsia food truck taxidermy before they sold out hoodie mustache. Disrupt trust fund gluten-free, tilde you probably haven’t heard of them whatever seitan hammock listicle tumblr. Venmo kale chips kitsch authentic raw denim pabst. Quinoa chicharrones flannel PBR&amp;B, narwhal sartorial jean shorts VHS DIY bespoke gastropub hella. Man braid squid humblebrag migas leggings, semiotics hella selvage kombucha blog williamsburg synth before they sold out. Plaid synth chicharrones, before they sold out neutra single-origin coffee cred. Pitchfork small batch etsy readymade, post-ironic pug viral.</p>\n<!-- /wp:paragraph -->', 'GETTING BACK TO NATURE IN A CANOE', '', 'publish', 'open', 'closed', '', 'getting-back-to-nature-in-a-canoe', '', '', '2019-01-15 04:28:30', '2019-01-15 04:28:30', '', 0, 'http://localhost/inhabitent/?post_type=adventure&#038;p=42', 0, 'adventure', '', 0),
(43, 1, '2019-01-15 04:29:16', '2019-01-15 04:29:16', '<!-- wp:paragraph {"placeholder":"Add Description"} -->\n<p>Street art VHS tattooed iPhone humblebrag. Listicle literally crucifix, meditation hoodie cold-pressed street art brooklyn four dollar toast swag. Lumbersexual tacos kinfolk, sriracha normcore meggings stumptown williamsburg neutra lo-fi 8-bit. Authentic microdosing try-hard pug brunch knausgaard. IPhone narwhal pour-over, tote bag man bun typewriter aesthetic sartorial pug mumblecore. Polaroid lo-fi hoodie, wayfarers chillwave quinoa cliche echo park +1 brooklyn etsy paleo gentrify salvia. Pitchfork 90’s hammock, 3 wolf moon bicycle rights chia slow-carb forage kombucha chicharrones.\n\nFranzen affogato next level artisan gluten-free bespoke. Brooklyn twee occupy, vinyl yr roof party jean shorts irony cray hella. Bushwick tilde pabst pour-over, semiotics poutine etsy tousled chambray. Slow-carb echo park jean shorts seitan. Salvia aesthetic gentrify man braid, messenger bag mixtape offal biodiesel chartreuse neutra. Williamsburg organic kickstarter pop-up literally. VHS lumbersexual migas roof party disrupt sartorial austin skateboard ethical.\n\nFixie bushwick tacos gastropub. Cliche neutra man bun vinyl authentic. Tote bag keytar synth knausgaard, asymmetrical flannel bushwick tacos dreamcatcher bitters small batch cronut godard hammock you probably haven’t heard of them. Swag meditation ramps crucifix chia messenger bag, tattooed schlitz banjo selfies farm-to-table mixtape. Direct trade fingerstache wayfarers franzen, godard intelligentsia bitters tacos chillwave etsy twee pabst plaid knausgaard single-origin coffee. Portland pug flexitarian, umami kale chips helvetica mustache taxidermy gluten-free disrupt fanny pack keffiyeh. Jean shorts pabst kinfolk, whatever vice wolf squid gastropub blog franzen swag.</p>\n<!-- /wp:paragraph -->', 'A Night with Friends at the Beach', '', 'publish', 'open', 'closed', '', 'a-night-with-friends-at-the-beach', '', '', '2019-01-15 04:29:16', '2019-01-15 04:29:16', '', 0, 'http://localhost/inhabitent/?post_type=adventure&#038;p=43', 0, 'adventure', '', 0),
(44, 1, '2019-01-15 04:29:53', '2019-01-15 04:29:53', '<!-- wp:paragraph {"placeholder":"Add Description"} -->\n<p>Man braid occupy crucifix shoreditch gluten-free skateboard. Artisan pour-over green juice swag cred before they sold out, cliche occupy keytar ennui aesthetic YOLO. Deep v chicharrones farm-to-table jean shorts. Pug raw denim portland schlitz, fanny pack church-key beard trust fund fashion axe pork belly tumblr waistcoat chillwave vinyl lo-fi. Gentrify direct trade post-ironic, tote bag biodiesel bushwick vegan synth readymade wolf cray aesthetic. Tacos farm-to-table next level occupy kitsch squid. Meggings brunch migas blog selvage yuccie farm-to-table.\n\nBanjo crucifix lomo mixtape vice. Hoodie kogi lumbersexual, williamsburg cred jean shorts pork belly trust fund scenester disrupt ramps kickstarter 3 wolf moon readymade food truck. Chia thundercats bespoke mustache, meggings flannel ugh slow-carb artisan. Cronut put a bird on it pickled semiotics yuccie. Occupy echo park fanny pack humblebrag. Fingerstache semiotics artisan food truck blue bottle. Gentrify drinking vinegar tilde, sustainable marfa chillwave hashtag direct trade distillery pinterest +1 wolf selfies.\n\nCardigan cronut fingerstache chartreuse hoodie everyday carry, pour-over kickstarter ethical try-hard stumptown truffaut kombucha whatever. 90’s bitters swag, intelligentsia XOXO affogato mlkshk everyday carry asymmetrical forage schlitz sustainable 8-bit lo-fi. Kogi tofu readymade, before they sold out put a bird on it banjo bitters master cleanse tumblr beard. Tousled etsy viral, retro stumptown squid iPhone poutine venmo. Retro narwhal gastropub banjo cold-pressed bitters, bespoke aesthetic single-origin coffee four loko cray. Man braid vinyl biodiesel, cliche DIY bitters hashtag austin polaroid portland intelligentsia kogi affogato photo booth. Pinterest cronut gastropub kogi knausgaard portland.</p>\n<!-- /wp:paragraph -->', 'Taking in the View at Big Mountain', '', 'publish', 'open', 'closed', '', 'taking-in-the-view-at-big-mountain', '', '', '2019-01-15 04:29:53', '2019-01-15 04:29:53', '', 0, 'http://localhost/inhabitent/?post_type=adventure&#038;p=44', 0, 'adventure', '', 0),
(45, 1, '2019-01-15 04:30:32', '2019-01-15 04:30:32', '<!-- wp:paragraph {"placeholder":"Add Description"} -->\n<p>Tote bag pitchfork food truck kickstarter quinoa sustainable. Literally +1 normcore bitters selvage, meditation bicycle rights jean shorts fap crucifix put a bird on it. Art party chillwave craft beer, distillery PBR&amp;B hoodie salvia bespoke keytar. Meditation chicharrones chartreuse meggings. Tattooed franzen narwhal tote bag. Raw denim chambray mlkshk tofu synth. Sartorial mlkshk four loko meggings, lumbersexual butcher vegan photo booth small batch vice pop-up salvia truffaut heirloom disrupt.\n\nYou probably haven’t heard of them ethical migas pour-over. You probably haven’t heard of them freegan hoodie butcher wayfarers truffaut. Artisan squid mustache thundercats +1. Asymmetrical selvage plaid butcher. Cronut small batch fashion axe blog VHS ennui. Vegan biodiesel four loko chambray, pickled marfa shoreditch sartorial chia stumptown mumblecore put a bird on it tacos. Keytar blue bottle tacos, stumptown skateboard pug sriracha ramps offal fap.\n\nStumptown lomo migas squid, ennui flexitarian normcore swag four dollar toast neutra authentic YOLO pour-over messenger bag organic. Chia distillery tofu sriracha lomo. Retro food truck hammock, pinterest next level everyday carry fanny pack meh typewriter pug bespoke tilde wayfarers williamsburg. Readymade flannel iPhone hella, brooklyn asymmetrical tacos actually humblebrag tilde affogato four dollar toast post-ironic blue bottle. Fashion axe mumblecore cornhole scenester. Authentic tofu XOXO vegan literally. Yuccie single-origin coffee fixie food truck, hashtag cardigan poutine hoodie slow-carb fanny pack flexitarian.</p>\n<!-- /wp:paragraph -->', 'Star-Gazing at the Night Sky', '', 'publish', 'open', 'closed', '', 'star-gazing-at-the-night-sky', '', '', '2019-01-15 04:30:32', '2019-01-15 04:30:32', '', 0, 'http://localhost/inhabitent/?post_type=adventure&#038;p=45', 0, 'adventure', '', 0),
(46, 1, '2019-01-15 04:31:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2019-01-15 04:31:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?post_type=product&p=46', 0, 'product', '', 0),
(47, 1, '2019-01-15 04:32:16', '2019-01-15 04:32:16', '', 'PRICE', '', 'publish', 'closed', 'closed', '', '47', '', '', '2019-01-15 04:33:14', '2019-01-15 04:33:14', '', 0, 'http://localhost/inhabitent/?post_type=cfs&#038;p=47', 0, 'cfs', '', 0),
(48, 1, '2019-01-15 04:32:22', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2019-01-15 04:32:22', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?post_type=product&p=48', 0, 'product', '', 0),
(49, 0, '2019-01-15 04:34:29', '2019-01-15 04:34:29', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'FILM CAMERA', '', 'publish', 'open', 'closed', '', 'film-camera', '', '', '2019-01-15 04:34:29', '2019-01-15 04:34:29', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=49', 0, 'product', '', 0),
(50, 0, '2019-01-15 04:35:17', '2019-01-15 04:35:17', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'RUSTIC TOOLS', '', 'publish', 'open', 'closed', '', 'rustic-tools', '', '', '2019-01-15 04:35:18', '2019-01-15 04:35:18', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=50', 0, 'product', '', 0),
(51, 0, '2019-01-15 04:35:58', '2019-01-15 04:35:58', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'WEATHERED CANOES', '', 'publish', 'open', 'closed', '', 'weathered-canoes', '', '', '2019-01-15 04:35:58', '2019-01-15 04:35:58', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=51', 0, 'product', '', 0),
(52, 0, '2019-01-15 04:36:45', '2019-01-15 04:36:45', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'WOOD AX', '', 'publish', 'open', 'closed', '', 'wood-ax', '', '', '2019-01-15 04:36:45', '2019-01-15 04:36:45', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=52', 0, 'product', '', 0),
(53, 0, '2019-01-15 04:37:35', '2019-01-15 04:37:35', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.<br></p>\n<!-- /wp:paragraph -->', 'CERAMIC MUG', '', 'publish', 'open', 'closed', '', 'ceramic-mug', '', '', '2019-01-15 04:37:36', '2019-01-15 04:37:36', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=53', 0, 'product', '', 0),
(54, 0, '2019-01-15 04:38:11', '2019-01-15 04:38:11', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'GAS STOVE', '', 'publish', 'open', 'closed', '', 'gas-stove', '', '', '2019-01-15 04:38:12', '2019-01-15 04:38:12', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=54', 0, 'product', '', 0),
(55, 1, '2019-01-15 04:38:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2019-01-15 04:38:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?post_type=product&p=55', 0, 'product', '', 0),
(56, 0, '2019-01-15 04:38:53', '2019-01-15 04:38:53', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'LARGE THERMOS', '', 'publish', 'open', 'closed', '', 'large-thermos', '', '', '2019-01-15 04:38:53', '2019-01-15 04:38:53', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=56', 0, 'product', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(57, 0, '2019-01-15 04:39:30', '2019-01-15 04:39:30', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'STEW CAN', '', 'publish', 'open', 'closed', '', 'stew-can', '', '', '2019-01-15 04:39:31', '2019-01-15 04:39:31', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=57', 0, 'product', '', 0),
(58, 0, '2019-01-15 04:40:32', '2019-01-15 04:40:32', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.<br></p>\n<!-- /wp:paragraph -->', 'BEACH TENT', '', 'publish', 'open', 'closed', '', 'beach-tent', '', '', '2019-01-15 04:40:33', '2019-01-15 04:40:33', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=58', 0, 'product', '', 0),
(59, 0, '2019-01-15 04:41:13', '2019-01-15 04:41:13', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'CAMPER VAN', '', 'publish', 'open', 'closed', '', 'camper-van', '', '', '2019-01-15 04:41:14', '2019-01-15 04:41:14', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=59', 0, 'product', '', 0),
(60, 0, '2019-01-15 04:43:28', '2019-01-15 04:43:28', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'NYLON TENTS', '', 'publish', 'open', 'closed', '', 'nylon-tents', '', '', '2019-01-15 04:43:28', '2019-01-15 04:43:28', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=60', 0, 'product', '', 0),
(61, 0, '2019-01-15 04:44:12', '2019-01-15 04:44:12', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'TRAVEL HAMMOCK', '', 'publish', 'open', 'closed', '', 'travel-hammock', '', '', '2019-01-15 04:44:13', '2019-01-15 04:44:13', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=61', 0, 'product', '', 0),
(62, 0, '2019-01-15 04:44:57', '2019-01-15 04:44:57', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'FLANNEL SHIRT', '', 'publish', 'open', 'closed', '', 'flannel-shirt', '', '', '2019-01-15 04:44:58', '2019-01-15 04:44:58', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=62', 0, 'product', '', 0),
(63, 0, '2019-01-15 04:45:37', '2019-01-15 04:45:37', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'HAND-KNIT TOQUE', '', 'publish', 'open', 'closed', '', 'hand-knit-toque', '', '', '2019-01-15 04:45:38', '2019-01-15 04:45:38', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=63', 0, 'product', '', 0),
(64, 0, '2019-01-15 04:46:21', '2019-01-15 04:46:21', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p><br>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'HIKING BOOTS', '', 'publish', 'open', 'closed', '', 'hiking-boots', '', '', '2019-01-15 04:46:22', '2019-01-15 04:46:22', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=64', 0, 'product', '', 0),
(65, 0, '2019-01-15 04:46:59', '2019-01-15 04:46:59', '<!-- wp:paragraph {"placeholder":"Add Description..."} -->\n<p>Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone. </p>\n<!-- /wp:paragraph -->', 'LEATHER SATCHEL', '', 'publish', 'open', 'closed', '', 'leather-satchel', '', '', '2019-01-15 04:46:59', '2019-01-15 04:46:59', '', 0, 'http://localhost/inhabitent/?post_type=product&#038;p=65', 0, 'product', '', 0),
(66, 1, '2019-01-15 04:49:37', '2019-01-15 04:49:37', '<!-- wp:heading -->\n<h2>OUR STORY</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co. has been Vancouver camping supply icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it&nbsp;every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2> OUR TEAM </h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent&nbsp;Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our shop&nbsp;is nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</p>\n<!-- /wp:paragraph -->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2019-01-15 06:28:21', '2019-01-15 06:28:21', '', 0, 'http://localhost/inhabitent/?page_id=66', 0, 'page', '', 0),
(67, 1, '2019-01-15 04:49:37', '2019-01-15 04:49:37', '', 'About', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2019-01-15 04:49:37', '2019-01-15 04:49:37', '', 66, 'http://localhost/inhabitent/2019/01/15/66-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2019-01-15 04:49:43', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-15 04:49:43', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?page_id=68', 0, 'page', '', 0),
(69, 1, '2019-01-15 04:49:51', '2019-01-15 04:49:51', '<!-- wp:heading -->\n<h2>WE TAKE CAMPING&nbsp;VERY SERIOUSLY.</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>\n\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal&nbsp;axes, we’ve got your covered.&nbsp;Please contact us below with any questions comments or suggestions.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[contact-form-7 id="99" title="FIND US"]\n<!-- /wp:shortcode -->', 'Find us', '', 'publish', 'closed', 'closed', '', 'find-us', '', '', '2019-01-15 07:51:17', '2019-01-15 07:51:17', '', 0, 'http://localhost/inhabitent/?page_id=69', 0, 'page', '', 0),
(70, 1, '2019-01-15 04:49:51', '2019-01-15 04:49:51', '', 'Find us', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-01-15 04:49:51', '2019-01-15 04:49:51', '', 69, 'http://localhost/inhabitent/2019/01/15/69-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2019-01-15 04:50:43', '2019-01-15 04:50:43', '', 'Journal', '', 'publish', 'closed', 'closed', '', 'journal', '', '', '2019-01-15 04:50:51', '2019-01-15 04:50:51', '', 0, 'http://localhost/inhabitent/?page_id=71', 0, 'page', '', 0),
(72, 1, '2019-01-15 04:50:43', '2019-01-15 04:50:43', '', 'JOURNAL', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2019-01-15 04:50:43', '2019-01-15 04:50:43', '', 71, 'http://localhost/inhabitent/2019/01/15/71-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2019-01-15 04:50:51', '2019-01-15 04:50:51', '', 'Journal', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2019-01-15 04:50:51', '2019-01-15 04:50:51', '', 71, 'http://localhost/inhabitent/2019/01/15/71-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2019-01-15 04:51:15', '2019-01-15 04:51:15', '', 'Inhabitent', '', 'publish', 'closed', 'closed', '', 'inhabitent', '', '', '2019-01-15 04:51:15', '2019-01-15 04:51:15', '', 0, 'http://localhost/inhabitent/?page_id=74', 0, 'page', '', 0),
(75, 1, '2019-01-15 04:51:15', '2019-01-15 04:51:15', '', 'Inhabitent', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2019-01-15 04:51:15', '2019-01-15 04:51:15', '', 74, 'http://localhost/inhabitent/2019/01/15/74-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2019-01-15 04:52:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 04:52:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=76', 1, 'nav_menu_item', '', 0),
(77, 1, '2019-01-15 04:52:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 04:52:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=77', 1, 'nav_menu_item', '', 0),
(78, 1, '2019-01-15 04:52:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 04:52:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=78', 1, 'nav_menu_item', '', 0),
(79, 1, '2019-01-15 04:52:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 04:52:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=79', 1, 'nav_menu_item', '', 0),
(80, 1, '2019-01-15 04:52:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 04:52:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=80', 1, 'nav_menu_item', '', 0),
(81, 1, '2019-01-15 04:52:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 04:52:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=81', 1, 'nav_menu_item', '', 0),
(82, 1, '2019-01-15 05:50:49', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 05:50:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=82', 1, 'nav_menu_item', '', 0),
(83, 1, '2019-01-15 05:52:30', '2019-01-15 05:52:30', ' ', '', '', 'publish', 'closed', 'closed', '', '83', '', '', '2019-01-15 05:53:52', '2019-01-15 05:53:52', '', 0, 'http://localhost/inhabitent/?p=83', 3, 'nav_menu_item', '', 0),
(84, 1, '2019-01-15 05:52:30', '2019-01-15 05:52:30', ' ', '', '', 'publish', 'closed', 'closed', '', '84', '', '', '2019-01-15 05:53:52', '2019-01-15 05:53:52', '', 0, 'http://localhost/inhabitent/?p=84', 4, 'nav_menu_item', '', 0),
(85, 1, '2019-01-15 05:50:49', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 05:50:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=85', 1, 'nav_menu_item', '', 0),
(86, 1, '2019-01-15 05:52:30', '2019-01-15 05:52:30', ' ', '', '', 'publish', 'closed', 'closed', '', '86', '', '', '2019-01-15 05:53:52', '2019-01-15 05:53:52', '', 0, 'http://localhost/inhabitent/?p=86', 2, 'nav_menu_item', '', 0),
(87, 1, '2019-01-15 05:50:49', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-15 05:50:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/inhabitent/?p=87', 1, 'nav_menu_item', '', 0),
(88, 1, '2019-01-15 05:52:30', '2019-01-15 05:52:30', '', 'SHOP', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2019-01-15 05:53:52', '2019-01-15 05:53:52', '', 0, 'http://localhost/inhabitent/?p=88', 1, 'nav_menu_item', '', 0),
(90, 1, '2019-01-15 06:28:21', '2019-01-15 06:28:21', '<!-- wp:heading -->\n<h2>OUR STORY</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co. has been Vancouver camping supply icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it&nbsp;every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2> OUR TEAM </h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent&nbsp;Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our shop&nbsp;is nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2019-01-15 06:28:21', '2019-01-15 06:28:21', '', 66, 'http://localhost/inhabitent/2019/01/15/66-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2019-01-15 06:30:41', '2019-01-15 06:30:41', '<h2>SEND US EMAIL!</h2>\r\n<p>Want to join the discussion? Feel free to contribute!</p>\r\n\r\n<label> COMMENT\r\n    [textarea your-message] </label>\r\n\r\n<label> Your Name (required)\r\n    [text* your-name] </label>\r\n\r\n<label> Your Email (required)\r\n    [email* your-email] </label>\r\n\r\n<label> WEBSITE\r\n    [text your-subject] </label>\r\n\r\n\r\n\r\n[submit "SUBMIT"]\n1\nInhabitent "[your-subject]"\nInhabitent <alexander.hortua10@gmail.com>\nalexander.hortua10@gmail.com\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)\nReply-To: [your-email]\n\n\n\n\nInhabitent "[your-subject]"\nInhabitent <alexander.hortua10@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)\nReply-To: alexander.hortua10@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2019-01-15 07:48:45', '2019-01-15 07:48:45', '', 0, 'http://localhost/inhabitent/?post_type=wpcf7_contact_form&#038;p=91', 0, 'wpcf7_contact_form', '', 0),
(92, 1, '2019-01-15 06:48:46', '2019-01-15 06:48:46', '<!-- wp:shortcode -->\n[contact-form-7 id="91" title="Contact form 1"]\n<!-- /wp:shortcode -->', 'Find us', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-01-15 06:48:46', '2019-01-15 06:48:46', '', 69, 'http://localhost/inhabitent/2019/01/15/69-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2019-01-15 07:30:15', '2019-01-15 07:30:15', '<!-- wp:heading -->\n<h2>WE TAKE CAMPING VERY SERIOUSLY.</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>\n\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal&nbsp;axes, we’ve got your covered.&nbsp;Please contact us below with any questions comments or suggestions.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[contact-form-7 id="91" title="Contact form 1"]\n<!-- /wp:shortcode -->', 'Find us', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-01-15 07:30:15', '2019-01-15 07:30:15', '', 69, 'http://localhost/inhabitent/2019/01/15/69-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2019-01-15 07:33:27', '2019-01-15 07:33:27', '{{unknown}}', '', '', 'publish', 'closed', 'closed', '', '8f8c2bca0dc7b13000be755a25a74daa', '', '', '2019-01-15 07:33:27', '2019-01-15 07:33:27', '', 0, 'http://localhost/inhabitent/2019/01/15/8f8c2bca0dc7b13000be755a25a74daa/', 0, 'oembed_cache', '', 0),
(96, 1, '2019-01-15 07:33:32', '2019-01-15 07:33:32', '<!-- wp:embed {"url":"https://maps.google.com/maps?width=760\\u0026amp;height=300\\u0026amp;hl=en\\u0026amp;q=1490%20W%20Broadway%2C%20Vancouver%2C%20BC%20V6H%204E8+(RED%20ACADEMY)\\u0026amp;ie=UTF8\\u0026amp;t=\\u0026amp;z=15\\u0026amp;iwloc=B\\u0026amp;output=embed\\u0022 frameborder=\\u00220\\u0022 scrolling=\\u0022no\\u0022 marginheight=\\u00220\\u0022 marginwidth=\\u00220\\u0022\\u003e\\u003c/iframe\\u003e\\u003cdiv style=\\u0022position: absolute;width: 80%;bottom: 20px;left: 0;right: 0;margin-left: auto;margin-right: auto;color: #000;\\u0022\\u003e\\u003csmall style=\\u0022line-height: 1.8;font-size: 8px;background: #fff;\\u0022\\u003ePowered by \\u003ca href=\\u0022https://embedgooglemaps.com/\\u0022\\u003eEmbedgooglemaps EN\\u003c/a\\u003e \\u0026 \\u003ca href=\\u0022http://fbaddlikebutton.com/\\u0022\\u003eFbaddlikebutton\\u003c/a\\u003e\\u003c/small\\u003e\\u003c/div\\u003e\\u003cstyle\\u003e#gmap_canvas img{max-width:none!important;background:none!important}","type":"rich","providerNameSlug":"embed-handler","className":""} -->\n<figure class="wp-block-embed is-type-rich is-provider-embed-handler"><div class="wp-block-embed__wrapper">\nhttps://maps.google.com/maps?width=760&amp;height=300&amp;hl=en&amp;q=1490%20W%20Broadway%2C%20Vancouver%2C%20BC%20V6H%204E8+(RED%20ACADEMY)&amp;ie=UTF8&amp;t=&amp;z=15&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0">&lt;/iframe>&lt;div style="position: absolute;width: 80%;bottom: 20px;left: 0;right: 0;margin-left: auto;margin-right: auto;color: #000;">&lt;small style="line-height: 1.8;font-size: 8px;background: #fff;">Powered by &lt;a href="https://embedgooglemaps.com/">Embedgooglemaps EN&lt;/a> &amp; &lt;a href="http://fbaddlikebutton.com/">Fbaddlikebutton&lt;/a>&lt;/small>&lt;/div>&lt;style>#gmap_canvas img{max-width:none!important;background:none!important}\n</div></figure>\n<!-- /wp:embed -->\n\n<!-- wp:heading -->\n<h2>WE TAKE CAMPING VERY SERIOUSLY.</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>\n\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal&nbsp;axes, we’ve got your covered.&nbsp;Please contact us below with any questions comments or suggestions.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[contact-form-7 id="91" title="Contact form 1"]\n<!-- /wp:shortcode -->', 'Find us', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-01-15 07:33:32', '2019-01-15 07:33:32', '', 69, 'http://localhost/inhabitent/2019/01/15/69-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2019-01-15 07:34:17', '2019-01-15 07:34:17', '{{unknown}}', '', '', 'publish', 'closed', 'closed', '', 'ff6f5bef27bf9b27bdda7e530adc2ec2', '', '', '2019-01-15 07:34:17', '2019-01-15 07:34:17', '', 0, 'http://localhost/inhabitent/2019/01/15/ff6f5bef27bf9b27bdda7e530adc2ec2/', 0, 'oembed_cache', '', 0),
(98, 1, '2019-01-15 07:35:11', '2019-01-15 07:35:11', '<!-- wp:heading -->\n<h2>WE TAKE CAMPING VERY SERIOUSLY.</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>\n\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal&nbsp;axes, we’ve got your covered.&nbsp;Please contact us below with any questions comments or suggestions.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[contact-form-7 id="91" title="Contact form 1"]\n<!-- /wp:shortcode -->', 'Find us', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-01-15 07:35:11', '2019-01-15 07:35:11', '', 69, 'http://localhost/inhabitent/2019/01/15/69-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2019-01-15 07:49:51', '2019-01-15 07:49:51', '<h2>SEND US EMAIL!</h2>\r\n\r\n<label> NAME <span class="asteristc">*</span>\r\n    [text* your-name] </label>\r\n\r\n<label> EMAIL <span class="asteristc">*</span> \r\n    [email* your-email] </label>\r\n\r\n<label> SUBJECT <span class="asteristc">*</span>\r\n    [text* your-subject] </label>\r\n\r\n<label> MESSAGE <span class="asteristc">*</span>\r\n    [textarea* your-message] </label>\r\n\r\n\r\n[submit "SUBMIT"]\n1\nInhabitent "[your-subject]"\nInhabitent <alexander.hortua10@gmail.com>\nalexander.hortua10@gmail.com\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)\nReply-To: [your-email]\n\n\n\n\nInhabitent "[your-subject]"\nInhabitent <alexander.hortua10@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Inhabitent (//localhost:3000/student)\nReply-To: alexander.hortua10@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'FIND US', '', 'publish', 'closed', 'closed', '', 'contact-form-1_copy', '', '', '2019-01-15 07:59:41', '2019-01-15 07:59:41', '', 0, 'http://localhost/inhabitent/?post_type=wpcf7_contact_form&#038;p=99', 0, 'wpcf7_contact_form', '', 0),
(101, 1, '2019-01-15 07:51:17', '2019-01-15 07:51:17', '<!-- wp:heading -->\n<h2>WE TAKE CAMPING&nbsp;VERY SERIOUSLY.</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>\n\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal&nbsp;axes, we’ve got your covered.&nbsp;Please contact us below with any questions comments or suggestions.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[contact-form-7 id="99" title="FIND US"]\n<!-- /wp:shortcode -->', 'Find us', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-01-15 07:51:17', '2019-01-15 07:51:17', '', 69, 'http://localhost/inhabitent/2019/01/15/69-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2019-01-15 08:37:34', '2019-01-15 08:37:34', '<!-- wp:paragraph -->\n<p>Inhabitent Camping Supply Co. has been Vancouver camping supply icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>OUR STORY</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it&nbsp;every day.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2> OUR TEAM </h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Inhabitent&nbsp;Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our shop&nbsp;is nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '66-autosave-v1', '', '', '2019-01-15 08:37:34', '2019-01-15 08:37:34', '', 66, 'http://localhost/inhabitent/2019/01/15/66-autosave-v1/', 0, 'revision', '', 0),
(103, 1, '2019-01-15 10:05:14', '2019-01-15 10:05:14', '<!-- wp:paragraph {"placeholder":"Add Description"} -->\n<p>Semiotics flannel artisan, squid whatever YOLO cold-pressed thundercats slow-carb normcore. Meggings lo-fi franzen waistcoat tattooed, pour-over etsy artisan. Seitan butcher tacos gentrify. Raw denim fap yr shabby chic. Thundercats mustache mlkshk messenger bag. Cronut crucifix wolf, artisan VHS skateboard chambray single-origin coffee fap. Shabby chic brooklyn meh kale chips, pour-over forage farm-to-table irony flannel mumblecore heirloom pickled cred.\n\nSwag chillwave chicharrones quinoa. Plaid yr small batch four loko. Polaroid scenester tattooed, biodiesel quinoa mumblecore 3 wolf moon leggings iPhone small batch sartorial meditation pop-up cardigan. Chillwave kitsch asymmetrical artisan, actually kogi cronut portland pork belly cardigan sustainable. Letterpress hammock heirloom kogi selvage biodiesel. Scenester occupy cornhole, banh mi post-ironic taxidermy crucifix mumblecore. Authentic pug next level, health goth slow-carb truffaut neutra literally biodiesel butcher retro.\n\nIntelligentsia food truck taxidermy before they sold out hoodie mustache. Disrupt trust fund gluten-free, tilde you probably haven’t heard of them whatever seitan hammock listicle tumblr. Venmo kale chips kitsch authentic raw denim pabst. Quinoa chicharrones flannel PBR&amp;B, narwhal sartorial jean shorts VHS DIY bespoke gastropub hella. Man braid squid humblebrag migas leggings, semiotics hella selvage kombucha blog williamsburg synth before they sold out. Plaid synth chicharrones, before they sold out neutra single-origin coffee cred. Pitchfork small batch etsy readymade, post-ironic pug viral.</p>\n<!-- /wp:paragraph -->', 'GETTING BACK TO NATURE IN A CANOE', '', 'inherit', 'closed', 'closed', '', '42-autosave-v1', '', '', '2019-01-15 10:05:14', '2019-01-15 10:05:14', '', 42, 'http://localhost/inhabitent/2019/01/15/42-autosave-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------

